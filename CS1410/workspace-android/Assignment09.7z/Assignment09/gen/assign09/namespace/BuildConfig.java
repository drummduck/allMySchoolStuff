/** Automatically generated file. DO NOT MODIFY */
package assign09.namespace;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}